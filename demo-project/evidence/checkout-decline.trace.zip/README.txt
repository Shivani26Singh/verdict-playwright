Demo trace placeholder for checkout-decline.
A real Playwright trace is produced by running the suite with trace: 'retain-on-failure'.