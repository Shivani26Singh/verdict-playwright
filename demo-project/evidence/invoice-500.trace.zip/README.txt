Demo trace placeholder for invoice-500.
A real Playwright trace is produced by running the suite with trace: 'retain-on-failure'.