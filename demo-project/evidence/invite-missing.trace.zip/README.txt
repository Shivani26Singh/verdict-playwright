Demo trace placeholder for invite-missing.
A real Playwright trace is produced by running the suite with trace: 'retain-on-failure'.