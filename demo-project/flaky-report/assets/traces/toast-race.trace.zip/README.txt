Demo trace placeholder for toast-race.
A real Playwright trace is produced by running the suite with trace: 'retain-on-failure'.