Demo trace placeholder for export-crash.
A real Playwright trace is produced by running the suite with trace: 'retain-on-failure'.