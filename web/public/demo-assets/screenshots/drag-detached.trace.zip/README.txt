Demo trace placeholder for drag-detached.
A real Playwright trace is produced by running the suite with trace: 'retain-on-failure'.