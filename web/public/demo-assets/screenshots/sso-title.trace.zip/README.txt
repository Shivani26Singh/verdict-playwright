Demo trace placeholder for sso-title.
A real Playwright trace is produced by running the suite with trace: 'retain-on-failure'.