Demo trace placeholder for kpi-mismatch.
A real Playwright trace is produced by running the suite with trace: 'retain-on-failure'.