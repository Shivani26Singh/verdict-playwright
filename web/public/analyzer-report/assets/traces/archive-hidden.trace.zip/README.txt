Demo trace placeholder for archive-hidden.
A real Playwright trace is produced by running the suite with trace: 'retain-on-failure'.