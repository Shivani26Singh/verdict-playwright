Demo trace placeholder for duplicate-strict.
A real Playwright trace is produced by running the suite with trace: 'retain-on-failure'.