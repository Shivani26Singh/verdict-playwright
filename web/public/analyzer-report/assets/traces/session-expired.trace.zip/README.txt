Demo trace placeholder for session-expired.
A real Playwright trace is produced by running the suite with trace: 'retain-on-failure'.