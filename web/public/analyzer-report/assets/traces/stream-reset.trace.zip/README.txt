Demo trace placeholder for stream-reset.
A real Playwright trace is produced by running the suite with trace: 'retain-on-failure'.